"""Focused test: Offside Trap has fired zero times across 17 real playthroughs. Rather than
hope a full match randomly produces its narrow trigger condition (a pass landing in the
defending side's frontmost column, D or H, with every single non-GK defender already pushed up
ahead of it), this script hand-crafts that exact scenario using the real sim.py/board.py
functions and my own driver's attempt_pass()/check_offside_trap() logic verbatim (copied from
run #17), to confirm the mechanic actually works when its condition is met. This does not
modify sim.py/board.py -- it just constructs a state by hand instead of playing full turns.
"""
import sys, os, json

sys.path.insert(0, r'C:\Users\cshad\Downloads\latesthexside')
os.chdir(r'C:\Users\cshad\AppData\Local\Temp\claude\C--Users-cshad\273b78da-a7f4-4bf6-9fc4-64c2519539d4\scratchpad\hexside_run18')

import sim, board as B

sim.gen_random()
s = sim.new_state()

def hex_dist(h1, h2):
    c1, r1 = B.parse(h1); c2, r2 = B.parse(h2)
    x1, x2 = B.COLS.index(c1), B.COLS.index(c2)
    Y1, Y2 = B.dY(c1, r1), B.dY(c2, r2)
    q1, q2 = x1, x2
    rr1, rr2 = (Y1 - x1) // 2, (Y2 - x2) // 2
    dq, dr = q2 - q1, rr2 - rr1
    return max(abs(dq), abs(dr), abs(dq + dr))

def attack_end(side):
    if side == 'A':
        return 'K' if s['a_defends_low'] else 'A'
    return 'A' if s['a_defends_low'] else 'K'

def defend_end(side):
    return 'A' if attack_end(side) == 'K' else 'K'

def check_offside_trap(defender_side, dest_hex):
    de = defend_end(defender_side)
    frontmost_col = 'D' if de == 'A' else 'H'
    print(f"    [check] defender {defender_side} defends the {de} end -> frontmost column {frontmost_col}; dest col {dest_hex[0]}")
    if dest_hex[0] != frontmost_col:
        return False
    third_cols = ('A', 'B', 'C', 'D') if de == 'A' else ('H', 'I', 'J', 'K')
    for u, h in s['pos'][defender_side].items():
        if u == 'GK':
            continue
        print(f"    [check] {defender_side}-{u} at {h} -- in own third columns {third_cols}? {h[0] in third_cols}")
        if h[0] in third_cols:
            return False
    return True

# --- Scenario setup ---
# a_defends_low is whatever new_state() rolled; force it deterministically for a clean test:
s['a_defends_low'] = True   # A defends the 'A' end (A3/A4), attacks 'K'; B defends 'K' (K3/K4), attacks 'A'
# So defend_end('B') == 'K' -> frontmost column H, third_cols = (H,I,J,K).
# B's back line must be ENTIRELY pushed up out of columns H-K (GK excepted) for the trap to apply.
s['pos'] = {
    'A': {'GK': 'A3', 'SW': 'C2', 'WB': 'C5', 'PM': 'G3', 'PO': 'H3'},
    'B': {'GK': 'K4', 'SW': 'E1', 'WB': 'E5', 'PM': 'F2', 'PO': 'F4'},
}
s['ball'] = {'side': 'A', 'unit': 'PM', 'hex': 'G3'}

print("Neighbors of G3 (passer's hex):", B.neighbors('G3'))
print("Straight line G3 -> H3:", B.straight_line('G3', 'H3'))

s['hand_tac']['B'] = ['OffsideTrap']
s['hand_tac']['A'] = ['ThroughBall']  # deliberately NOT enough to matter -- irrelevant to this test
s['hand_tac']['B'] = ['OffsideTrap']
s['flair'] = {'A': 0, 'B': 3}
s['hand_cmd']['A'] = []
s['hand_cmd']['B'] = []

print("\nBEFORE pass attempt:")
sim.show(s)

def attempt_pass(side, opp, cu, ch, free=False):
    prange = sim.ROSTER[cu]['prange']
    end = attack_end(side); box = B.GOAL_BOX[end]
    teammates_all = [(u, h) for u, h in s['pos'][side].items() if u != cu]
    teammates_pref = [(u, h) for u, h in teammates_all if u != 'GK']

    def _best_in_range(cands):
        b = None
        for u2, h2 in cands:
            d, _ = B.straight_line(ch, h2)
            if d is not None and 0 < d <= prange:
                sd = min(hex_dist(h2, x) for x in box)
                if b is None or sd < b[2]:
                    b = (u2, h2, sd, d)
        return b

    best = _best_in_range(teammates_pref) or _best_in_range(teammates_all)
    if not best:
        print("  No legal in-range teammate found -- test scenario geometry needs adjusting.")
        return False
    u2, h2, _, d = best
    print(f"  Passer {side}-{cu} at {ch} targets teammate {u2} at {h2} (distance {d}, within Pass Range {prange})")

    if check_offside_trap(opp, h2) and 'OffsideTrap' in s['hand_tac'][opp] and s['flair'][opp] >= 2:
        s['hand_tac'][opp].remove('OffsideTrap'); s['flair'][opp] -= 2
        s['ball'] = {'side': None, 'unit': None, 'hex': h2}
        print(f"  {opp} plays Offside Trap (Tactic, 2 Flair) -- pass into {h2} cancelled, ball loose there (sec12 simplified)")
        return 'OFFSIDE_TRAP_FIRED'
    print("  Offside Trap did NOT trigger -- pass would proceed normally.")
    return True

result = attempt_pass('A', 'B', 'PM', 'G3')

print("\nAFTER pass attempt:")
sim.show(s)
print(f"\nRESULT: {result}")

print("\n\n===== NEGATIVE CONTROL: pull one B defender back into its own Third =====")
s['pos'] = {
    'A': {'GK': 'A3', 'SW': 'C2', 'WB': 'C5', 'PM': 'G3', 'PO': 'H3'},
    'B': {'GK': 'K4', 'SW': 'E1', 'WB': 'E5', 'PM': 'F2', 'PO': 'H5'},  # PO now sitting in column H
}
s['ball'] = {'side': 'A', 'unit': 'PM', 'hex': 'G3'}
s['hand_tac']['B'] = ['OffsideTrap']
s['flair']['B'] = 3
result2 = attempt_pass('A', 'B', 'PM', 'G3')
print(f"\nRESULT (should NOT be OFFSIDE_TRAP_FIRED): {result2}")
print(f"Offside Trap still in B's hand? {'OffsideTrap' in s['hand_tac']['B']}")
