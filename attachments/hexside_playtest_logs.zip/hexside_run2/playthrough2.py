"""Playthrough #2: same parameters as #1 (6 turns/side, Tactic deck never played, Discipline
deck live) but with a smarter driver heuristic: units now chase loose balls, and non-carrying
units close in on the opposing ball-carrier (feeding the existing Tackle logic) instead of
blindly marching toward their own attacking end regardless of ball state.

Still does not modify sim.py/board.py. The only addition is a private hex-distance helper
(hex_dist) used purely for the driver's own movement-ranking heuristic -- it is NOT used for
any rules legality check; those still go through the real board.straight_line/shot_dist calls.
"""
import sys, os, json, traceback

sys.path.insert(0, r'C:\Users\cshad\Downloads\latesthexside')
os.chdir(r'C:\Users\cshad\AppData\Local\Temp\claude\C--Users-cshad\273b78da-a7f4-4bf6-9fc4-64c2519539d4\scratchpad\hexside_run2')

import sim, board as B

NOTES = []
def note(msg):
    NOTES.append(msg)
    print(f"\n### ENGINE NOTE: {msg}\n")

def hex_dist(h1, h2):
    """Generic hex distance (driver-only heuristic, not a rules function). board.py's
    neighbor deltas (0,+-2) and (+-1,+-1) in (col-index, dY) space form a standard axial
    hex grid once you set q = x, r = (Y - x) / 2; axial distance is max(|dq|,|dr|,|dq+dr|)."""
    c1, r1 = B.parse(h1); c2, r2 = B.parse(h2)
    x1, x2 = B.COLS.index(c1), B.COLS.index(c2)
    Y1, Y2 = B.dY(c1, r1), B.dY(c2, r2)
    q1, q2 = x1, x2
    rr1, rr2 = (Y1 - x1) // 2, (Y2 - x2) // 2
    dq, dr = q2 - q1, rr2 - rr1
    return max(abs(dq), abs(dr), abs(dq + dr))

sim.gen_random()
s = sim.new_state()
print(f"Coin flip winner / kicker: {s['kicker']}   a_defends_low={s['a_defends_low']}")

def attack_end(side):
    if side == 'A':
        return 'K' if s['a_defends_low'] else 'A'
    return 'A' if s['a_defends_low'] else 'K'

def other(side):
    return 'B' if side == 'A' else 'A'

def maybe_claim(side, unit):
    if s['ball']['side'] is None and s['pos'][side].get(unit) == s['ball']['hex']:
        s['ball'] = {'side': side, 'unit': unit, 'hex': s['ball']['hex']}
        print(f"  {side}-{unit} claims the loose ball at {s['ball']['hex']}")

def attempt_pass(side, opp, cu, ch, free=False):
    prange = sim.ROSTER[cu]['prange']
    teammates = [(u, h) for u, h in s['pos'][side].items() if u != cu]
    end = attack_end(side)
    box = B.GOAL_BOX[end]
    best = None
    for u2, h2 in teammates:
        d, _ = B.straight_line(ch, h2)
        if d is not None and 0 < d <= prange:
            sd = min(hex_dist(h2, b) for b in box)
            if best is None or sd < best[2]:
                best = (u2, h2, sd, d)
    if not best:
        return False
    u2, h2, _, d = best
    _, mids = B.straight_line(ch, h2)
    zoc = sim.enemy_zoc(s, side)
    line_hexes = mids + [h2]
    contested = any(m in zoc for m in line_hexes)
    tag = "(free follow-up) " if free else ""
    if contested:
        defender_unit = None
        for uu, hh in s['pos'][opp].items():
            if any(B.adjacent(hh, m) for m in line_hexes):
                defender_unit = uu
                break
        win, ah, dh = sim.contest(s, side, sim.ROSTER[cu]['control'], opp,
                                   sim.ROSTER[defender_unit]['control'],
                                   label=f"{tag}Pass {side}-{cu}->{u2}")
        if win:
            s['ball'] = {'side': side, 'unit': u2, 'hex': h2}
            print(f"  {tag}Pass succeeds: {cu} -> {u2} at {h2}")
        else:
            s['ball'] = {'side': opp, 'unit': defender_unit, 'hex': s['pos'][opp][defender_unit]}
            print(f"  {tag}Pass INTERCEPTED by {opp}-{defender_unit} at {s['pos'][opp][defender_unit]}")
    else:
        s['ball'] = {'side': side, 'unit': u2, 'hex': h2}
        print(f"  {tag}Pass (uncontested): {cu} -> {u2} at {h2}")
    return True

def attempt_shot(side, opp, cu, ch):
    end = attack_end(side)
    srange = sim.ROSTER[cu]['srange']
    dist_net = B.shot_dist(ch, end)
    if srange is None or dist_net is None or dist_net > srange:
        return False
    box = B.GOAL_BOX[end]
    defenders_in_box = [u for u, h in s['pos'][opp].items() if h in box]
    if not defenders_in_box:
        s['score'][side] += 1
        print(f"  {cu} SHOOTS from {ch} -- goal box EMPTY -> AUTOMATIC GOAL! {s['score']['A']}-{s['score']['B']}")
        sim.goal_restart(s, opp)
        return True
    gk_list = [u for u, h in s['pos'][opp].items() if u == 'GK']
    gk = gk_list[0] if gk_list else defenders_in_box[0]
    win, ah, dh = sim.contest(s, side, sim.ROSTER[cu]['shot'], opp, sim.ROSTER[gk]['save'],
                              label=f"Shot {side}-{cu} from {ch}")
    if win:
        s['score'][side] += 1
        print(f"  GOAL! {s['score']['A']}-{s['score']['B']}")
        sim.goal_restart(s, opp)
    else:
        gk_hex = s['pos'][opp].get(gk)
        other_box_hex = [h for h in box if h != gk_hex]
        other_box_hex = other_box_hex[0] if other_box_hex else box[0]
        s['ball'] = {'side': None, 'unit': None, 'hex': other_box_hex}
        print(f"  SAVE -- ball loose at {other_box_hex}")
    return True

TURNS_PER_SIDE = 6
first = s['kicker']
order = []
for _ in range(TURNS_PER_SIDE):
    order.append(first)
    order.append(other(first))

turn_no = 0
for side in order:
    turn_no += 1
    s['turn'] = turn_no
    opp = other(side)
    print(f"\n===== TURN {turn_no}: {side} to play (attacks the {attack_end(side)} end) =====")
    sim.show(s)

    try:
        hand = [c for c in s['hand_cmd'][side] if c != 'Counter']
        if not hand:
            c = s['hand_cmd'][side][0]
            s['hand_cmd'][side].remove(c)
            s['hand_cmd'][side].append(sim.draw_cmd(s, side))
            note(f"Turn {turn_no} ({side}): all-Counter hand deadlock -- forced to cycle (§5).")
            sim.save(s)
            continue

        card = hand[0]
        units, fallback = sim.card_options(s, side, card)
        s['hand_cmd'][side].remove(card)
        carrier_side, carrier_unit = s['ball']['side'], s['ball']['unit']
        has_ball = (carrier_side == side)

        if card == 'TacticalFree':
            pick = []
            if has_ball and carrier_unit in units:
                pick.append(carrier_unit)
            for u in units:
                if u not in pick:
                    pick.append(u)
                if len(pick) == 2:
                    break
            activated = pick
        elif fallback:
            if has_ball and carrier_unit in units:
                activated = [carrier_unit]
            else:
                activated = units[:1]
        else:
            activated = units

        print(f"{side} plays {card} (fallback={fallback}) -> activates {activated}")

        for unit in list(activated):
            if unit not in s['pos'][side]:
                continue
            maybe_claim(side, unit)
            start_hex = s['pos'][side][unit]
            is_carrier = (side == s['ball']['side'] and unit == s['ball']['unit'])
            reachable = sim.reach(s, side, unit)

            if is_carrier:
                end = attack_end(side)
                box = B.GOAL_BOX[end]
                target = min(box, key=lambda b: hex_dist(start_hex, b))
                cand = sorted(reachable.items(), key=lambda kv: hex_dist(kv[0], target))
                dest, (cost, path) = cand[0]
                zoc = sim.enemy_zoc(s, side)
                entry_idx = None
                for i, h in enumerate(path[1:], start=1):
                    if h in zoc:
                        entry_idx = i
                        break
                if entry_idx is not None:
                    contested_hex = path[entry_idx]
                    prev_hex = path[entry_idx - 1]
                    defender_unit = None
                    for u2, h2 in s['pos'][opp].items():
                        if B.adjacent(h2, contested_hex):
                            defender_unit = u2
                            break
                    win, ah, dh = sim.contest(s, side, sim.ROSTER[unit]['control'], opp,
                                               sim.ROSTER[defender_unit]['tackle'],
                                               label=f"Dribble Challenge {side}-{unit} into {contested_hex}")
                    if win:
                        s['pos'][side][unit] = dest
                        s['ball']['hex'] = dest
                        print(f"  {unit} wins Dribble Challenge, carries through {start_hex}->{dest}")
                    else:
                        s['pos'][side][unit] = contested_hex
                        s['ball'] = {'side': None, 'unit': None, 'hex': prev_hex}
                        print(f"  {unit} LOSES Dribble Challenge; unit ends at {contested_hex}, ball spills loose to {prev_hex}")
                else:
                    s['pos'][side][unit] = dest
                    s['ball']['hex'] = dest
                    print(f"  {unit} (carrier) moves {start_hex} -> {dest}, no Zone of Control entered")
                sim.check_no_overlap(s)
            else:
                if s['ball']['side'] == opp:
                    target = s['ball']['hex']            # chase the opposing carrier to enable a Tackle
                elif s['ball']['side'] is None:
                    target = s['ball']['hex']             # chase the loose ball
                else:
                    end = attack_end(side)
                    box = B.GOAL_BOX[end]
                    target = min(box, key=lambda b: hex_dist(start_hex, b))  # support run upfield
                cand = sorted(reachable.items(), key=lambda kv: hex_dist(kv[0], target))
                dest, _ = cand[0]
                if s['ball']['side'] == opp and B.adjacent(dest, s['ball']['hex']):
                    if sim.would_seal_last_gap(s, side, opp, s['ball']['hex'], dest):
                        alt = [h for h, _ in cand if h != dest]
                        if alt:
                            dest = alt[0]
                            note(f"Turn {turn_no} ({side}): escape-hex rule (§8) blocked the closest square for {unit}; rerouted to {dest}.")
                s['pos'][side][unit] = dest
                sim.check_no_overlap(s)
                print(f"  {unit} moves {start_hex} -> {dest}")
                maybe_claim(side, unit)

        acted = False
        if s['ball']['side'] == side and s['ball']['unit'] in activated:
            cu = s['ball']['unit']
            ch = s['pos'][side][cu]
            if not attempt_shot(side, opp, cu, ch):
                acted = attempt_pass(side, opp, cu, ch)
            else:
                acted = True
        elif s['ball']['side'] == opp:
            adjacent_defenders = [u for u in activated
                                   if u in s['pos'][side] and B.adjacent(s['pos'][side][u], s['ball']['hex'])]
            if adjacent_defenders:
                tackler = max(adjacent_defenders, key=lambda u: sim.ROSTER[u]['tackle'])
                carrier_u = s['ball']['unit']
                win, ah, dh = sim.tackle(s, side, tackler, opp, sim.ROSTER[tackler]['tackle'],
                                          sim.ROSTER[carrier_u]['control'],
                                          label=f"Tackle {side}-{tackler} on {opp}-{carrier_u}")
                if win:
                    s['ball'] = {'side': side, 'unit': tackler, 'hex': s['pos'][side][tackler]}
                    print(f"  Tackle WON -- {side}-{tackler} takes the ball at {s['pos'][side][tackler]}")
                    attempt_pass(side, opp, tackler, s['pos'][side][tackler], free=True)
                else:
                    print(f"  Tackle FAILS -- ball stays with {opp}-{carrier_u}")
                acted = True

        sim.replenish(s, side)
        sim.save(s)
    except Exception as e:
        note(f"Turn {turn_no} ({side}): RUNTIME EXCEPTION -- {e}")
        traceback.print_exc()

print("\n\n===== FINAL STATE =====")
sim.show(s)
print(f"\nFinal score after {TURNS_PER_SIDE} turns/side: A {s['score']['A']} - {s['score']['B']} B")
print(f"Yellow-carded units: {s.get('yellow', [])}")
print(f"Sent off: {s.get('sent_off', [])}")
print(f"Flair banked: {s['flair']}")
print(f"Full Press debt outstanding: {s['debt']}")
print(f"Discipline draws made this match: {s['p_disc']}")

print("\n===== ENGINE NOTES COLLECTED DURING PLAY =====")
if NOTES:
    for n in NOTES:
        print(f"- {n}")
else:
    print("(none)")
