# Hexside playtest bundle — index

Companion to the [Hexside Match Report](https://claude.ai/code/artifact/dddbbaae-5aad-4254-9a81-0c7cbd7c9226).
Each folder is one test session's driver script(s) plus its raw console transcript(s), run
against the unmodified `sim.py` / `board.py` you provided — nothing in this bundle edited
either file.

Match numbers below match the report's discipline-log table (1–28).

| Match # | Folder | File | Configuration |
|---|---|---|---|
| 1 | hexside_run1 | *(no log saved — output was only reviewed inline)* | 6/side, no Tactics, naive movement heuristic |
| 2 | hexside_run2 | *(no log saved)* | 6/side, no Tactics, chase-loose-ball fix |
| 3 | hexside_run3 | *(no log saved)* | 6/side, no Tactics, GK-stays-home fix |
| 4 | hexside_run4 | full_log.txt | 12/side, no Tactics |
| 5 | hexside_run5 | full_log.txt | 12/side, Tactics partially wired |
| 6 | hexside_run6 | full_log.txt | 12/side, full 13-card Tactic deck first wired |
| 7 | hexside_run7 | full_log.txt | 24/side, first full match w/ halftime |
| 8 | hexside_run8 | full_log.txt | 24/side, full match repeat |
| 9 | hexside_run9 | full_log.txt | Replay of #8, B tackling conservative |
| 10 | hexside_run10 | full_log.txt | Both sides conservative tackling, fresh |
| 11 | hexside_run11 | full_log.txt | Both conservative, fresh #2 |
| 12 | hexside_run12 | full_log.txt | Both conservative, fresh #3 |
| 13 | hexside_run13 | full_log.txt + resume_log.txt | Ruthless A vs. deep B v1 — **crashed at turn 36** (KeyError bug, see report), resumed after the fix, then hit the Command-Deck-exhaustion bug from turn 42 onward |
| 14 | hexside_run14 | full_log.txt | Same matchup, fresh, both bugs fixed |
| 15 | hexside_run15 | full_log.txt | Same matchup, A's Goalkeeper restrained |
| 16 | hexside_run16 | full_log.txt | Same matchup, GK-as-pass-target fix added |
| 17 | hexside_run17 | full_log.txt | Symmetric full-Tactics baseline, all fixes combined |
| 18 | hexside_run19 | full_log.txt | Jockey trial, narrow trigger (0 fires) |
| 19 | hexside_run19 | full_log2.txt | Jockey trial, widened trigger #1 |
| 20 | hexside_run19 | full_log_3.txt | Jockey trial, widened trigger #2 |
| 21 | hexside_run19 | full_log_4.txt | Jockey trial, widened trigger #3 |
| 22 | hexside_run19 | full_log_5.txt | Jockey trial, widened trigger #4 (Jockey fires twice) |
| 23 | hexside_run20 | full_log.txt | Double length: 48/side, 96 total turns |
| 24 | hexside_run21 | full_log.txt | Shot Range +1 validation, fresh #1 |
| 25 | hexside_run21 | full_log_2.txt | Shot Range +1 validation, fresh #2 |
| 26 | hexside_run21 | full_log_3.txt | Shot Range +1 validation, fresh #3 |
| 27 | hexside_run21 | full_log_4.txt | Shot Range +1 validation, fresh #4 |
| 28 | hexside_run21 | full_log_5.txt | Shot Range +1 validation, fresh #5 |

## Not part of the match sequence, but included

- `hexside_run18/offside_trap_test.py` — hand-crafted positive/negative-control test proving
  the Offside Trap mechanic works correctly in isolation (it just never arose in real play).
  Console output wasn't captured to a file; re-run it to reproduce.
- `hexside_run19/jockey_unit_test.py` — isolated test confirming the Jockey mechanic (Pace
  reduction, card/Flair consumption, `sim.reach()` recompute) works correctly. Same note —
  re-run to reproduce the printed output.

## What's *not* included

Each run also produced a `state.json` (final match state) and `game_random.json` (the
pre-generated dice/card/coin-flip stream that turn actually consumed) alongside its log —
left out of this bundle for size and relevance, since the `.txt` transcripts already capture
everything that happened. Ask if you want those for exact byte-for-byte reproduction of a
specific match.

## How every one of these was produced

Every `playthroughN.py` script is a self-contained driver: it imports `sim`/`board` unmodified
from the actual project folder, pre-generates a Command/Tactic/dice/Discipline stream (either
via `sim.gen_random()` directly, or via an in-driver `gen_random_long()` workaround for the
Command/Tactic-deck-exhaustion bug — see the report), then plays out full turns by calling the
real `card_options()`, `reach()`, `contest()`, `tackle()`, `slide_tackle()`, `enemy_zoc()`,
`goal_restart()`, and `halftime_reset()` functions exactly as documented. All Tactic Card
effects, Reactions (Counter/Press/Foul/Advantage Play), and movement/targeting heuristics are
implemented in the driver script itself, since `sim.py` only tracks hand sizes generically —
none of that logic lives in the engine files.
