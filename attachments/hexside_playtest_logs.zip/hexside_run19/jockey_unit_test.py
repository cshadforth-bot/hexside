"""Focused test: Jockey fired zero times in run #19's full match despite being drawn 20 times
into each side's hand. Confirm whether the mechanism itself works when its condition is
plainly met (opponent adjacent to the carrier's start hex, card held, enough Flair)."""
import sys, os

sys.path.insert(0, r'C:\Users\cshad\Downloads\latesthexside')
os.chdir(r'C:\Users\cshad\AppData\Local\Temp\claude\C--Users-cshad\273b78da-a7f4-4bf6-9fc4-64c2519539d4\scratchpad\hexside_run19')

import sim, board as B

sim.gen_random()
s = sim.new_state()

def maybe_jockey(carrier_side, defender_side, carrier_hex):
    adjacent = [u for u, h in s['pos'][defender_side].items() if B.adjacent(h, carrier_hex)]
    print(f"  [check] {defender_side} units adjacent to {carrier_side}'s carrier at {carrier_hex}: {adjacent}")
    if adjacent and 'Jockey' in s['hand_tac'][defender_side] and s['flair'][defender_side] >= 1:
        s['hand_tac'][defender_side].remove('Jockey'); s['flair'][defender_side] -= 1
        jockeyer = adjacent[0]
        print(f"  {defender_side} plays Jockey (Tactic, 1 Flair) via {jockeyer} -- {carrier_side}'s carrier loses 1 Pace this move")
        return 1
    return 0

# A carries the ball at G3; B's Sweeper is right next to it at F3 -- should trigger.
s['pos'] = {
    'A': {'GK': 'A3', 'SW': 'C2', 'WB': 'C5', 'PM': 'E2', 'PO': 'G3'},
    'B': {'GK': 'K4', 'SW': 'F3', 'WB': 'I5', 'PM': 'G4', 'PO': 'I2'},
}
s['ball'] = {'side': 'A', 'unit': 'PO', 'hex': 'G3'}
s['hand_tac']['B'] = ['Jockey']
s['flair']['B'] = 2

print("Is F3 adjacent to G3?", B.adjacent('F3', 'G3'))
print("PO's normal reach (Pace 4):", sorted(sim.reach(s, 'A', 'PO').keys()))

penalty = maybe_jockey('A', 'B', 'G3')
print(f"\nPenalty returned: {penalty}")
if penalty:
    reduced = sim.reach(s, 'A', 'PO', extra_pace=-penalty)
    print("PO's reach AFTER Jockey (Pace 3):", sorted(reduced.keys()))
print(f"Jockey still in B's hand? {'Jockey' in s['hand_tac']['B']}")
print(f"B's Flair after: {s['flair']['B']}")
