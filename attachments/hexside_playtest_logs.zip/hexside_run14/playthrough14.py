"""Playthrough #13: a fresh full match with two deliberately contrasting, asymmetric styles
instead of a shared driver policy:

  Team A -- ruthlessly / unnecessarily aggressive:
    - Tackles every single time it's adjacent to the ball-carrier, no restraint (should_tackle
      always True), always uses Slide Tackle when held regardless of risk, and always uses
      Press/Counter to force extra Tackle Challenges when available.
    - The Goalkeeper is NOT special-cased at all -- it presses and chases exactly like any
      outfield unit (chases loose balls and the opposing carrier anywhere on the pitch, no
      "stay near the box" restraint), which is exactly the kind of reckless overcommitment
      "unnecessarily aggressive" implies.

  Team B -- deep and counter-attacking:
    - Only ever commits to a Tackle Challenge (standing, Slide, or forced via Press/Counter)
      with its Sweeper, and only when the ball-carrier is already inside B's own defensive
      Third -- a genuine last-ditch challenge, never a proactive press.
    - The Goalkeeper never leaves the goal box, full stop (no "valid reason" override at all).
    - Outfield non-carrier units fall back toward B's own goal box when B doesn't have the
      ball, UNLESS the ball is already a real threat inside B's own defensive Third (then they
      close in to defend it) -- a deep defensive block.
    - The Poacher is the counter-attacking outlet: while B doesn't have the ball it barely
      moves (holds its advanced position rather than tracking back), ready to receive a quick
      out-ball the moment B wins possession.

Also includes two fixes discovered while running #13's match:
  1. attempt_pass() now re-derives the intercepting defender AFTER the opponent's Reaction
     resolves, not before -- a forced Tackle Challenge in that reaction can itself send off
     the very unit that would have intercepted, and the stale reference crashed with
     KeyError('SW') at run #13's turn 36.
  2. sim.py's gen_random() only ever pre-shuffles a single 35-card Command Deck (and 26-card
     Tactic Deck) per side with no reshuffle-on-empty, despite sec5 explicitly requiring one
     ("reshuffle the discard pile when the draw pile runs out"). A full 48-turn match with
     heavy Full Press/cycling exhausted Team A's pool at turn 42 in run #13, and every
     subsequent draw threw IndexError for the rest of the match. Rather than touching
     sim.py/board.py, gen_random_long() below is a driver-side-only workaround: it builds the
     exact same shape of game_random.json sim.py itself reads, just concatenating several
     independently-shuffled copies of sim.py's own COMMAND/TACTIC/DISCIPLINE_DECK data so a
     long, cycling-heavy match can't run any of those pools dry. This does not change any
     rule-processing code in sim.py/board.py -- only how much of the same-shaped random
     support data gets pre-generated.

Still does not modify sim.py/board.py.
"""
import sys, os, json, traceback, random

sys.path.insert(0, r'C:\Users\cshad\Downloads\latesthexside')
os.chdir(r'C:\Users\cshad\AppData\Local\Temp\claude\C--Users-cshad\273b78da-a7f4-4bf6-9fc4-64c2519539d4\scratchpad\hexside_run14')

import sim, board as B

def gen_random_long(copies=10):
    """Driver-side-only workaround for sim.py's Command/Tactic Deck never reshuffling once
    exhausted -- see module docstring. Builds `copies`x the normal amount of the exact same
    shape of data sim.gen_random() produces, using sim.py's own deck/dice/discipline
    definitions (sim.COMMAND, sim.TACTIC, sim.DISCIPLINE_DECK, sim._expand) so the content is
    identical, just with enough independently-reshuffled repeats that a long match can't
    outrun any single pool."""
    rng = random.Random()
    r = {}
    r['coinflip'] = rng.choice(['A', 'B'])
    for side in ('A', 'B'):
        cmd = []
        for _ in range(copies):
            block = sim._expand(sim.COMMAND); rng.shuffle(block); cmd += block
        r['command_' + side] = cmd
        tac = []
        for _ in range(copies):
            block = sim._expand(sim.TACTIC); rng.shuffle(block); tac += block
        r['tactic_' + side] = tac
        r['dice_' + side] = [rng.randint(1, 6) for _ in range(400 * copies)]
    pool = sim._expand(sim.DISCIPLINE_DECK)
    r['discipline'] = rng.choices(pool, k=600 * copies)
    json.dump(r, open(sim.RAND, 'w'))
    return r

NOTES = []
def note(msg):
    NOTES.append(msg)
    print(f"\n### ENGINE NOTE: {msg}\n")

def hex_dist(h1, h2):
    c1, r1 = B.parse(h1); c2, r2 = B.parse(h2)
    x1, x2 = B.COLS.index(c1), B.COLS.index(c2)
    Y1, Y2 = B.dY(c1, r1), B.dY(c2, r2)
    q1, q2 = x1, x2
    rr1, rr2 = (Y1 - x1) // 2, (Y2 - x2) // 2
    dq, dr = q2 - q1, rr2 - rr1
    return max(abs(dq), abs(dr), abs(dq + dr))

def should_tackle(side, tackler, carrier_hex):
    """A: ruthlessly aggressive -- always commits. B: deep/counter -- only its Sweeper, and
    only as a last-ditch challenge when the ball-carrier is already inside B's own defensive
    Third."""
    if side == 'A':
        return True
    if tackler != 'SW':
        return False
    de = defend_end('B')
    own_third = 1 if de == 'A' else 3
    return B.third(B.parse(carrier_hex)[0]) == own_third

gen_random_long()
s = sim.new_state()
print(f"Coin flip winner / kicker: {s['kicker']}   a_defends_low={s['a_defends_low']}")

def attack_end(side):
    if side == 'A':
        return 'K' if s['a_defends_low'] else 'A'
    return 'A' if s['a_defends_low'] else 'K'

def defend_end(side):
    return 'A' if attack_end(side) == 'K' else 'K'

def other(side):
    return 'B' if side == 'A' else 'A'

def maybe_claim(side, unit):
    if s['ball']['side'] is None and s['pos'][side].get(unit) == s['ball']['hex']:
        s['ball'] = {'side': side, 'unit': unit, 'hex': s['ball']['hex']}
        print(f"  {side}-{unit} claims the loose ball at {s['ball']['hex']}")

def _do_forced_tackle(defender_side, tackler, carrier_side, carrier_hex):
    carrier_u = s['ball']['unit']
    win, ah, dh = sim.tackle(s, defender_side, tackler, carrier_side, sim.ROSTER[tackler]['tackle'],
                              sim.ROSTER[carrier_u]['control'],
                              label=f"Forced Tackle ({defender_side}-{tackler}) on {carrier_side}-{carrier_u}")
    if win:
        s['ball'] = {'side': defender_side, 'unit': tackler, 'hex': s['pos'][defender_side][tackler]}
        print(f"  Forced Tackle WON -- original action CANCELLED, {defender_side}-{tackler} takes the ball")
        attempt_pass(defender_side, carrier_side, tackler, s['pos'][defender_side][tackler], free=True)
        return tackler
    print(f"  Forced Tackle FAILS -- original action proceeds normally")
    return None

def maybe_reaction(active_side, defender_side, carrier_hex):
    adjacent_units = [u for u, h in s['pos'][defender_side].items() if B.adjacent(h, carrier_hex)]
    adjacent_units = [u for u in adjacent_units if should_tackle(defender_side, u, carrier_hex)]
    if adjacent_units and 'Press' in s['hand_tac'][defender_side] and s['flair'][defender_side] >= 1:
        s['hand_tac'][defender_side].remove('Press'); s['flair'][defender_side] -= 1
        tackler = max(adjacent_units, key=lambda u: sim.ROSTER[u]['tackle'])
        print(f"  {defender_side} plays Press (Tactic, 1 Flair): forces a Tackle Challenge via {tackler}")
        return _do_forced_tackle(defender_side, tackler, active_side, carrier_hex), 0
    if adjacent_units and 'Counter' in s['hand_cmd'][defender_side]:
        s['hand_cmd'][defender_side].remove('Counter')
        tackler = max(adjacent_units, key=lambda u: sim.ROSTER[u]['tackle'])
        print(f"  {defender_side} discards a Counter: forces a Tackle Challenge via {tackler}")
        return _do_forced_tackle(defender_side, tackler, active_side, carrier_hex), 0
    if 'Counter' in s['hand_cmd'][defender_side]:
        s['hand_cmd'][defender_side].remove('Counter')
        print(f"  {defender_side} discards a Counter -- +1 Defense die on this roll")
        return None, 1
    return None, 0

def maybe_foul(active_side, defender_side, carrier_hex):
    adjacent = [u for u, h in s['pos'][defender_side].items() if B.adjacent(h, carrier_hex)]
    if not adjacent or 'Foul' not in s['hand_tac'][defender_side]:
        return False
    if 'AdvantagePlay' in s['hand_tac'][active_side] and s['flair'][active_side] >= 1:
        s['hand_tac'][active_side].remove('AdvantagePlay'); s['flair'][active_side] -= 1
        print(f"  {defender_side} could call a Foul, but {active_side} plays Advantage Play (1 Flair) to play on")
        return False
    s['hand_tac'][defender_side].remove('Foul')
    fouler = adjacent[0]
    card = sim.draw_disc_foul(s)
    sim.apply_discipline(s, defender_side, fouler, card)
    s['ball'] = {'side': None, 'unit': None, 'hex': carrier_hex}
    print(f"  {defender_side} calls a FOUL (Tactic, free) via {fouler} -- play stopped, ball loose at {carrier_hex} (sec12 simplified: no full Free Kick sequence)")
    return True

def check_offside_trap(defender_side, dest_hex):
    de = defend_end(defender_side)
    frontmost_col = 'D' if de == 'A' else 'H'
    if dest_hex[0] != frontmost_col:
        return False
    third_cols = ('A', 'B', 'C', 'D') if de == 'A' else ('H', 'I', 'J', 'K')
    for u, h in s['pos'][defender_side].items():
        if u == 'GK':
            continue
        if h[0] in third_cols:
            return False
    return True

def resolve_contest(atk_side, atk_dice, def_side, def_dice, label, allow_lastditch=False):
    av, af, ah = sim.roll(s, atk_side, atk_dice, True)
    dv, df, dh = sim.roll(s, def_side, def_dice, False)
    tag = ""
    if allow_lastditch and ah > dh and 'LastDitchBlock' in s['hand_tac'][def_side] and s['flair'][def_side] >= 2:
        s['hand_tac'][def_side].remove('LastDitchBlock'); s['flair'][def_side] -= 2
        ah -= 1
        tag = " [Last-Ditch Block cancels 1 Success]"
    win = ah > dh
    line = f"[{label}]{tag} {atk_side} rolls {av}->{af} ({ah} succ) | {def_side} rolls {dv}->{df} ({dh} stop) => {'ATTACKER WINS' if win else 'DEFENDER HOLDS'}"
    s['log'].append(line); print(line)
    return win, ah, dh

def resolve_dribble_contest(atk_side, atk_dice, def_side, def_dice, label):
    av, af, ah = sim.roll(s, atk_side, atk_dice, True)
    dv, df, dh = sim.roll(s, def_side, def_dice, False)
    win = ah > dh
    tag = ""
    if not win and 'Nutmeg' in s['hand_tac'][atk_side] and s['flair'][atk_side] >= 2 and af.count('flair') >= 1:
        s['hand_tac'][atk_side].remove('Nutmeg'); s['flair'][atk_side] -= 2
        win = True
        tag = " [Nutmeg -- Flair symbol wins outright]"
    elif not win and 'StepOver' in s['hand_tac'][atk_side] and s['flair'][atk_side] >= 1:
        s['hand_tac'][atk_side].remove('StepOver'); s['flair'][atk_side] -= 1
        n = min(2, len(av))
        idx = sorted(range(len(av)), key=lambda i: av[i])[:n]
        nv, nf, _ = sim.roll(s, atk_side, n, True)
        for j, i in enumerate(idx):
            av[i] = nv[j]; af[i] = nf[j]
        ah = af.count('success')
        win = ah > dh
        tag = f" [Step-Over -- rerolled {n} dice]"
    line = f"[{label}]{tag} {atk_side} rolls {av}->{af} ({ah} succ) | {def_side} rolls {dv}->{df} ({dh} stop) => {'ATTACKER WINS' if win else 'DEFENDER HOLDS'}"
    s['log'].append(line); print(line)
    return win, ah, dh

def attempt_backheel(side, cu, ch):
    if 'Backheel' in s['hand_tac'][side] and s['flair'][side] >= 1:
        teammates = [(u, h) for u, h in s['pos'][side].items() if u != cu and B.adjacent(ch, h)]
        if teammates:
            u2, h2 = teammates[0]
            s['hand_tac'][side].remove('Backheel')
            s['flair'][side] -= 1
            s['ball'] = {'side': side, 'unit': u2, 'hex': h2}
            print(f"  Backheel (Tactic, 1 Flair): {cu} -> {u2} at {h2}, free -- Act still available")
            return u2, h2
    return None

def attempt_one_two(side, cu, ch):
    if 'OneTwo' not in s['hand_tac'][side] or s['flair'][side] < 1:
        return None
    teammates = [(u, h) for u, h in s['pos'][side].items() if u != cu and B.adjacent(ch, h)]
    if not teammates:
        return None
    end = attack_end(side); box = B.GOAL_BOX[end]
    occ = sim.occupied(s)
    best = None
    for u2, h2 in teammates:
        for nh in B.neighbors(h2):
            if nh in occ or nh == ch:
                continue
            d = min(hex_dist(nh, b) for b in box)
            if best is None or d < best[2]:
                best = (u2, h2, d, nh)
    if not best:
        return None
    u2, h2, d, nh = best
    cur_d = min(hex_dist(ch, b) for b in box)
    if d >= cur_d:
        return None
    s['hand_tac'][side].remove('OneTwo'); s['flair'][side] -= 1
    s['pos'][side][cu] = nh
    s['ball']['hex'] = nh
    print(f"  One-Two (Tactic, 1 Flair): {cu} bounces off {u2} at {h2} -> ends up at {nh}")
    sim.check_no_overlap(s)
    return cu, nh

def attempt_pass(side, opp, cu, ch, free=False):
    prange = sim.ROSTER[cu]['prange']
    end = attack_end(side); box = B.GOAL_BOX[end]
    teammates = [(u, h) for u, h in s['pos'][side].items() if u != cu]
    best = None
    for u2, h2 in teammates:
        d, _ = B.straight_line(ch, h2)
        if d is not None and 0 < d <= prange:
            sd = min(hex_dist(h2, b) for b in box)
            if best is None or sd < best[2]:
                best = (u2, h2, sd, d)
    long_ball_used = False
    if not best and 'LongBall' in s['hand_tac'][side] and s['flair'][side] >= 2:
        for u2, h2 in teammates:
            d, _ = B.straight_line(ch, h2)
            if d is not None and d > prange:
                sd = min(hex_dist(h2, b) for b in box)
                if best is None or sd < best[2]:
                    best = (u2, h2, sd, d)
        if best:
            long_ball_used = True
    if not best:
        return False
    u2, h2, _, d = best
    if long_ball_used:
        s['hand_tac'][side].remove('LongBall'); s['flair'][side] -= 2
        print(f"  Long Ball (Tactic, 2 Flair): {cu} -> {u2} at {h2} ({d} hexes, beyond normal Pass Range {prange})")
    tag = "(free follow-up) " if free else ""

    if maybe_foul(side, opp, ch):
        return True

    if check_offside_trap(opp, h2) and 'OffsideTrap' in s['hand_tac'][opp] and s['flair'][opp] >= 2:
        s['hand_tac'][opp].remove('OffsideTrap'); s['flair'][opp] -= 2
        s['ball'] = {'side': None, 'unit': None, 'hex': h2}
        print(f"  {opp} plays Offside Trap (Tactic, 2 Flair) -- pass into {h2} cancelled, ball loose there (sec12 simplified)")
        return True

    zoc = sim.enemy_zoc(s, side)
    if long_ball_used:
        line_hexes = [h2]
        contested = h2 in zoc
    else:
        _, mids = B.straight_line(ch, h2)
        line_hexes = mids + [h2]
        contested = any(m in zoc for m in line_hexes)

    if contested and 'ThroughBall' in s['hand_tac'][side] and s['flair'][side] >= 1:
        s['hand_tac'][side].remove('ThroughBall')
        s['flair'][side] -= 1
        s['ball'] = {'side': side, 'unit': u2, 'hex': h2}
        print(f"  {tag}Through Ball (Tactic, 1 Flair): {cu} -> {u2} at {h2}, ZoC ignored, no roll needed")
        return True

    if contested:
        forced_tackler, extra_die = maybe_reaction(side, opp, ch)
        if forced_tackler:
            return True
        # Re-derive the intercepting defender AFTER the reaction, not before: a forced Tackle
        # Challenge just above can itself draw a Red Card (via sim.tackle()'s internal
        # Discipline draw) and remove the very unit that would have intercepted this pass --
        # a stale reference here crashed with KeyError on that unit the first time a match
        # got aggressive enough to hit it (playthrough #13, turn 36).
        defender_unit = None
        for uu, hh in s['pos'][opp].items():
            if any(B.adjacent(hh, m) for m in line_hexes):
                defender_unit = uu
                break
        if defender_unit is None:
            s['ball'] = {'side': side, 'unit': u2, 'hex': h2}
            print(f"  {tag}Pass succeeds (the reaction above removed the only intercepting unit): {cu} -> {u2} at {h2}")
            return True
        win, ah, dh = resolve_contest(side, sim.ROSTER[cu]['control'], opp,
                                       sim.ROSTER[defender_unit]['control'] + extra_die,
                                       label=f"{tag}Pass {side}-{cu}->{u2}", allow_lastditch=True)
        if win:
            s['ball'] = {'side': side, 'unit': u2, 'hex': h2}
            print(f"  {tag}Pass succeeds: {cu} -> {u2} at {h2}")
        else:
            s['ball'] = {'side': opp, 'unit': defender_unit, 'hex': s['pos'][opp][defender_unit]}
            print(f"  {tag}Pass INTERCEPTED by {opp}-{defender_unit} at {s['pos'][opp][defender_unit]}")
    else:
        s['ball'] = {'side': side, 'unit': u2, 'hex': h2}
        print(f"  {tag}Pass (uncontested): {cu} -> {u2} at {h2}")
    return True

def attempt_shot(side, opp, cu, ch):
    end = attack_end(side)
    srange = sim.ROSTER[cu]['srange']
    dist_net = B.shot_dist(ch, end)
    if srange is None or dist_net is None or dist_net > srange:
        return False
    box = B.GOAL_BOX[end]
    defenders_in_box = [u for u, h in s['pos'][opp].items() if h in box]
    if not defenders_in_box:
        s['score'][side] += 1
        print(f"  {cu} SHOOTS from {ch} -- goal box EMPTY -> AUTOMATIC GOAL! {s['score']['A']}-{s['score']['B']}")
        sim.goal_restart(s, opp)
        return True
    gk_list = [u for u, h in s['pos'][opp].items() if u == 'GK']
    gk = gk_list[0] if gk_list else defenders_in_box[0]
    shot_dice = sim.ROSTER[cu]['shot']
    lane = B.lane(*B.parse(ch))
    if lane in ('Top', 'Bottom') and 'CurlShot' in s['hand_tac'][side] and s['flair'][side] >= 2:
        s['hand_tac'][side].remove('CurlShot'); s['flair'][side] -= 2
        shot_dice += 1
        print(f"  Curl Shot (Tactic, 2 Flair): +1 Attack die ({lane} lane)")
    forced_tackler, extra_die = maybe_reaction(side, opp, ch)
    if forced_tackler:
        return True
    win, ah, dh = resolve_contest(side, shot_dice, opp, sim.ROSTER[gk]['save'] + extra_die,
                                   label=f"Shot {side}-{cu} from {ch}", allow_lastditch=True)
    if win:
        s['score'][side] += 1
        print(f"  GOAL! {s['score']['A']}-{s['score']['B']}")
        sim.goal_restart(s, opp)
    else:
        gk_hex = s['pos'][opp].get(gk)
        other_box_hex = [h for h in box if h != gk_hex]
        other_box_hex = other_box_hex[0] if other_box_hex else box[0]
        s['ball'] = {'side': None, 'unit': None, 'hex': other_box_hex}
        print(f"  SAVE -- ball loose at {other_box_hex}")
    return True

TURNS_PER_SIDE = 24
HALF = TURNS_PER_SIDE // 2
first = s['kicker']
order = []
for _ in range(HALF):
    order.append(first); order.append(other(first))
second_kicker = other(first)
for _ in range(HALF):
    order.append(second_kicker); order.append(other(second_kicker))
HALFTIME_INDEX = 2 * HALF
print(f"First-half kicker: {first}   Second-half kicker (per §14, the side that didn't open): {second_kicker}")

turn_no = 0
for idx, side in enumerate(order):
    if idx == HALFTIME_INDEX:
        sim.halftime_reset(s)
    turn_no += 1
    s['turn'] = turn_no
    opp = other(side)
    print(f"\n===== TURN {turn_no}: {side} to play (attacks the {attack_end(side)} end) =====")
    sim.show(s)

    try:
        hand = [c for c in s['hand_cmd'][side] if c != 'Counter']
        if not hand:
            c = s['hand_cmd'][side][0]
            s['hand_cmd'][side].remove(c)
            s['hand_cmd'][side].append(sim.draw_cmd(s, side))
            note(f"Turn {turn_no} ({side}): all-Counter hand deadlock -- forced to cycle (§5).")
            sim.save(s)
            continue

        card = hand[0]
        units, fallback = sim.card_options(s, side, card)
        s['hand_cmd'][side].remove(card)
        carrier_side, carrier_unit = s['ball']['side'], s['ball']['unit']
        has_ball = (carrier_side == side)

        if card == 'TacticalFree':
            pick = []
            if has_ball and carrier_unit in units:
                pick.append(carrier_unit)
            for u in units:
                if u not in pick:
                    pick.append(u)
                if len(pick) == 2:
                    break
            activated = pick
        elif fallback:
            if has_ball and carrier_unit in units:
                activated = [carrier_unit]
            else:
                activated = units[:1]
        else:
            activated = units

        print(f"{side} plays {card} (fallback={fallback}) -> activates {activated}")

        for unit in list(activated):
            if unit not in s['pos'][side]:
                continue
            maybe_claim(side, unit)
            start_hex = s['pos'][side][unit]
            is_carrier = (side == s['ball']['side'] and unit == s['ball']['unit'])
            reachable = sim.reach(s, side, unit)

            if is_carrier:
                end = attack_end(side)
                box = B.GOAL_BOX[end]
                target = min(box, key=lambda b: hex_dist(start_hex, b))
                cand = sorted(reachable.items(), key=lambda kv: hex_dist(kv[0], target))
                dest, (cost, path) = cand[0]
                zoc = sim.enemy_zoc(s, side)
                entry_idx = None
                for i, h in enumerate(path[1:], start=1):
                    if h in zoc:
                        entry_idx = i
                        break
                if entry_idx is not None:
                    contested_hex = path[entry_idx]
                    prev_hex = path[entry_idx - 1]
                    if maybe_foul(side, opp, prev_hex):
                        s['pos'][side][unit] = prev_hex
                    else:
                        defender_unit = None
                        for u2, h2 in s['pos'][opp].items():
                            if B.adjacent(h2, contested_hex):
                                defender_unit = u2
                                break
                        forced_tackler, extra_die = maybe_reaction(side, opp, contested_hex)
                        if forced_tackler:
                            s['pos'][side][unit] = start_hex
                        else:
                            win, ah, dh = resolve_dribble_contest(side, sim.ROSTER[unit]['control'], opp,
                                                                   sim.ROSTER[defender_unit]['tackle'] + extra_die,
                                                                   label=f"Dribble Challenge {side}-{unit} into {contested_hex}")
                            if win:
                                s['pos'][side][unit] = dest
                                s['ball']['hex'] = dest
                                print(f"  {unit} wins Dribble Challenge, carries through {start_hex}->{dest}")
                            else:
                                s['pos'][side][unit] = contested_hex
                                s['ball'] = {'side': None, 'unit': None, 'hex': prev_hex}
                                print(f"  {unit} LOSES Dribble Challenge; unit ends at {contested_hex}, ball spills loose to {prev_hex}")
                else:
                    s['pos'][side][unit] = dest
                    s['ball']['hex'] = dest
                    print(f"  {unit} (carrier) moves {start_hex} -> {dest}, no Zone of Control entered")
                sim.check_no_overlap(s)
            elif unit == 'GK' and side == 'B':
                # Deep team: the keeper NEVER leaves the box, no exceptions.
                de = defend_end(side)
                box = B.GOAL_BOX[de]
                target = min(box, key=lambda b: hex_dist(start_hex, b))
                cand = sorted(reachable.items(), key=lambda kv: hex_dist(kv[0], target))
                dest, _ = cand[0]
                s['pos'][side][unit] = dest
                sim.check_no_overlap(s)
                print(f"  GK holds the box (deep team, no exceptions): {start_hex} -> {dest}")
                maybe_claim(side, unit)
            else:
                # side == 'A': ruthlessly aggressive -- GK included, chases everything, everywhere.
                if side == 'A':
                    if s['ball']['side'] == opp:
                        target = s['ball']['hex']
                    elif s['ball']['side'] is None:
                        target = s['ball']['hex']
                    else:
                        end = attack_end(side)
                        box = B.GOAL_BOX[end]
                        target = min(box, key=lambda b: hex_dist(start_hex, b))
                # side == 'B', outfield (SW/WB/PM/PO): deep block, except the Poacher holds
                # its advanced spot as the counter-attacking outlet rather than tracking back.
                elif unit == 'PO':
                    if s['ball']['side'] == side:
                        end = attack_end(side)
                        box = B.GOAL_BOX[end]
                        target = min(box, key=lambda b: hex_dist(start_hex, b))
                    else:
                        target = start_hex
                else:
                    de = defend_end(side)
                    own_third = 1 if de == 'A' else 3
                    danger_hex = None
                    if s['ball']['side'] == opp:
                        danger_hex = s['ball']['hex']
                    elif s['ball']['side'] is None:
                        danger_hex = s['ball']['hex']
                    in_danger = danger_hex is not None and B.third(B.parse(danger_hex)[0]) == own_third
                    if s['ball']['side'] == side:
                        end = attack_end(side)
                        box = B.GOAL_BOX[end]
                        target = min(box, key=lambda b: hex_dist(start_hex, b))
                    elif in_danger:
                        target = danger_hex
                    else:
                        box = B.GOAL_BOX[de]
                        target = min(box, key=lambda b: hex_dist(start_hex, b))
                cand = sorted(reachable.items(), key=lambda kv: hex_dist(kv[0], target))
                dest, _ = cand[0]
                if s['ball']['side'] == opp and B.adjacent(dest, s['ball']['hex']):
                    if sim.would_seal_last_gap(s, side, opp, s['ball']['hex'], dest):
                        alt = [h for h, _ in cand if h != dest]
                        if alt:
                            dest = alt[0]
                            note(f"Turn {turn_no} ({side}): escape-hex rule (§8) blocked the closest square for {unit}; rerouted to {dest}.")
                s['pos'][side][unit] = dest
                sim.check_no_overlap(s)
                print(f"  {unit} moves {start_hex} -> {dest}")
                maybe_claim(side, unit)

        acted = False
        if s['ball']['side'] == side and s['ball']['unit'] in activated:
            cu = s['ball']['unit']
            ch = s['pos'][side][cu]
            bh = attempt_backheel(side, cu, ch)
            if bh is not None:
                u2, h2 = bh
                if u2 in activated:
                    cu, ch = u2, h2
                else:
                    cu = None
            if cu is not None:
                if not attempt_shot(side, opp, cu, ch):
                    ot = attempt_one_two(side, cu, ch)
                    if ot is not None:
                        cu, ch = ot
                        acted = True
                    else:
                        acted = attempt_pass(side, opp, cu, ch)
                else:
                    acted = True
        elif s['ball']['side'] == opp:
            adjacent_defenders = [u for u in activated
                                   if u in s['pos'][side] and B.adjacent(s['pos'][side][u], s['ball']['hex'])]
            adjacent_defenders = [u for u in adjacent_defenders if should_tackle(side, u, s['ball']['hex'])]
            if adjacent_defenders:
                tackler = max(adjacent_defenders, key=lambda u: sim.ROSTER[u]['tackle'])
                carrier_u = s['ball']['unit']
                bonus = 0
                if 'Counter' in s['hand_cmd'][opp]:
                    s['hand_cmd'][opp].remove('Counter')
                    bonus = 1
                    print(f"  {opp} discards a Counter -- +1 Defense die on this Tackle")
                if 'SlideTackle' in s['hand_tac'][side]:
                    win, ah, dh = sim.slide_tackle(s, side, tackler, opp, sim.ROSTER[tackler]['tackle'],
                                                    sim.ROSTER[carrier_u]['control'] + bonus,
                                                    label=f"Tackle {side}-{tackler} on {opp}-{carrier_u}")
                else:
                    win, ah, dh = sim.tackle(s, side, tackler, opp, sim.ROSTER[tackler]['tackle'],
                                              sim.ROSTER[carrier_u]['control'] + bonus,
                                              label=f"Tackle {side}-{tackler} on {opp}-{carrier_u}")
                if win:
                    s['ball'] = {'side': side, 'unit': tackler, 'hex': s['pos'][side][tackler]}
                    print(f"  Tackle WON -- {side}-{tackler} takes the ball at {s['pos'][side][tackler]}")
                    attempt_pass(side, opp, tackler, s['pos'][side][tackler], free=True)
                else:
                    print(f"  Tackle FAILS -- ball stays with {opp}-{carrier_u}")
                acted = True

        sim.replenish(s, side)
        sim.save(s)
    except Exception as e:
        note(f"Turn {turn_no} ({side}): RUNTIME EXCEPTION -- {e}")
        traceback.print_exc()

print("\n\n===== FINAL STATE =====")
sim.show(s)
print(f"\nFinal score after {TURNS_PER_SIDE} turns/side (full match, halftime included): A {s['score']['A']} - {s['score']['B']} B")
print(f"Yellow-carded units: {s.get('yellow', [])}")
print(f"Sent off: {s.get('sent_off', [])}")
print(f"Flair banked: {s['flair']}")
print(f"Full Press debt outstanding: {s['debt']}")
print(f"Discipline draws made this match: {s['p_disc']}")

print("\n===== ENGINE NOTES COLLECTED DURING PLAY =====")
if NOTES:
    for n in NOTES:
        print(f"- {n}")
else:
    print("(none)")
